document.getElementById("demo1").innerHTML="Tài liệu học CSS";
document.getElementById("demo2").innerHTML="Tài liệu học MySQL";
document.getElementById("demo3").innerHTML="Tài liệu học PHP";
